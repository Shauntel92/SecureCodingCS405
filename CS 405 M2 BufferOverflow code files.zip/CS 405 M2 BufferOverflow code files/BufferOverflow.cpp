// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>
#include <cstring>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;


  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  
  // Secure coding fixes
  // 1) Read into a std::string first so the user cannot overflow a fixed-size buffer.
  // 2) Validate the length against the destination buffer capacity.
  // 3) If the user entered too much data, notify them and safely truncate.
  std::string temp;
  std::cin >> temp;

  // Reserve 1 byte for the null terminator
  constexpr std::size_t kBufferSize = sizeof(user_input);
  constexpr std::size_t kMaxChars = kBufferSize - 1;

  if (temp.size() > kMaxChars) {
      std::cout << "Warning: input too long (" << temp.size()
          << " chars). Max allowed is " << kMaxChars
          << ". Input will be truncated." << std::endl;
  }
  
  // Copy at most kMaxChars bytes and ensure explicit null termination
  strncpy_s(user_input, sizeof(user_input), temp.c_str(), kMaxChars);
  

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
